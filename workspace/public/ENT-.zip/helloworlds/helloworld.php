<?php
 echo "Hello world!";

 // On peut aussi utiliser les guillemets simples
  echo 'Hello World!';
?>
