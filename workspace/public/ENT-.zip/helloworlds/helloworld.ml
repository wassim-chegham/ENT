let hello () =
  print_string "Hello world!";
  print_newline();;
let main () =
  hello();
  exit 0;;
main();;

